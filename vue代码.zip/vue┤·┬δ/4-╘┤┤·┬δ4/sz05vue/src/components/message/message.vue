<template>
    <div class="tmpl">
        我是消息
    </div>
</template>


