export default{
    apihost:'http://webhm.top:8899/' //只需要更改这个值，那么对应的开发环境和生产环境就可以来回切换了
}