var path = require('path')

var webpack = require('webpack')

module.exports = {
    entry:'./entry.js',
    output:{
        path: path.join(__dirname),
        filename: 'bundle.js'
    },
    module: {//模块
        loaders: [//loader
            {
                test: /\.css$/, 
                loader: 'style-loader!css-loader'
            }
        ]
    },
    plugins:[
        new webpack.BannerPlugin('这个文件是 great yellow 生成的')
    ]
}