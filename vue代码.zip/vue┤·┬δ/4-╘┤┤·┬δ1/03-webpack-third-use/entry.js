document.write('It is time for lunch.<br/>')
var name = require('./module.js')
document.write(name)

//导入我们项目需要用到的css
// require('!style-loader!css-loader!./site.css')
require('./site.css')
require('./site2.css')