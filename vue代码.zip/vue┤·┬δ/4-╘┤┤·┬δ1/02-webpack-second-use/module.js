var name = "小可爱"

module.exports = name