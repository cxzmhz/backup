document.write('It works.<br/>')
var name = require('./module.js')
document.write(name)