


import Vue from 'vue';//var Vue = require('vue')
import App from './App.vue';
import VueRouter from 'vue-router';
import VueResource from 'vue-resource';
import Mint from 'mint-ui';
import moment from 'moment';
import VuePreview from 'vue-preview';
import Vuex from 'vuex';


import 'mint-ui/lib/style.css';
import './statics/mui/css/mui.css'
import './statics/css/site.css'
import common from './common/common.js'

import home from './components/home/home.vue'
import category from './components/category/category.vue'
import shopcart from './components/shopcart/shopcart.vue'
import mine from './components/mine/mine.vue'
import newslist from './components/news/newslist.vue'
import newsinfo from './components/news/newsinfo.vue'
import photolist from './components/photo/photolist.vue'
import photoinfo from './components/photo/photoinfo.vue'
import goodslist from './components/goods/goodslist.vue'
import goodsinfo from './components/goods/goodsinfo.vue'
import photoAndText from './components/goods/photoAndText.vue'
import goodscomment from './components/goods/goodscomment.vue'

Vue.use(Mint);
Vue.use(VueRouter);
Vue.use(VueResource);
Vue.use(VuePreview);
Vue.use(Vuex);
Vue.filter('dateFmt', (input, formatStr) => {
   const formatStr1 = formatStr || 'YYYY-MM-DD HH:mm:ss';
   return moment(input).format(formatStr1);
})
var router = new VueRouter({
   routes: [
      { path: '/', redirect: '/home' },
      { path: '/home', component: home },
      { path: '/category', component: category },
      { path: '/shopcart', component: shopcart },
      { path: '/mine', component: mine },
      { path: '/news/newslist', component: newslist },
      { path: '/news/newsinfo/:newsId', component: newsinfo },
      { path: '/photo/photolist', component: photolist },
      { path: '/photo/photoinfo/:photoId', component: photoinfo },
      { path: '/goods/goodslist', component: goodslist },
      { path: '/goods/goodsinfo/:goodsId', component: goodsinfo },
      { name: 'photoAndText', path: '/goods/photoAndText', component: photoAndText },
      { path: '/goods/goodscomment', component: goodscomment }

   ]
})

const store = new Vuex.Store({
   state: {
      goodsList: []
   },
   getters: {
      getGoodsList(state) {
         return state.goodsList;
      },
      getGoodsCount(state) {
         var count = 0;
         state.goodsList.forEach(v => {
            count += v.count;
         })
         return count;
      }

   },
   mutations: {
      getMuGoods(state, goodsObj) {
         state.goodsList.push(goodsObj);
      },
      deleteGoods(state, id) {
         state.goodsList = state.goodsList.filter(
            v => {
               return v.id != id;
            }
         );
      }
   },
   actions: {
      getActionGoods(context, goodsObj) {
         context.commit('getMuGoods', goodsObj);
      }
   }
})

new Vue({
   el: '#app',
   router,
   store,
   render: h => h(App)
})
