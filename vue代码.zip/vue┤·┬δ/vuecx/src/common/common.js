module.exports = {
   url: "http://vue.studyit.io/"
}