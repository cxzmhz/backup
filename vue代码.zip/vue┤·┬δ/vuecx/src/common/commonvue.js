import Vue from 'vue';
const bus = new Vue({
   data: {
      a: 1
   }
});
export default bus