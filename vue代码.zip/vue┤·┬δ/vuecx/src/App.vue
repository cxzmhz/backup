<template>
   <div>
      <mt-header fixed title="CXZ♥XJY">
      </mt-header>
      <span class="forBack" @click="goback()" v-show="isbackshow">&lt;返回</span>
      <router-view class="centerContent">

      </router-view>
      <mt-tabbar fixed :class="{istabshow:isactive}">
         <mt-tab-item>
            <router-link to="/home">
               <img src="//st.360buyimg.com/m/images/index/a-home.png">
            </router-link>
         </mt-tab-item>
         <mt-tab-item>
            <router-link to="/category">
               <img src="//st.360buyimg.com/m/images/index/n-catergry.png">
            </router-link>
         </mt-tab-item>
         <mt-tab-item>
            <router-link to="/shopcart" class="upbox">
               <span class="upflag" v-show="upflag!=0">{{upflag}}</span>
               <img src="//st.360buyimg.com/m/images/index/n-cart.png">
            </router-link>
         </mt-tab-item>
         <mt-tab-item>
            <router-link to="mine">
               <img src="//st.360buyimg.com/m/images/index/n-me.png">
            </router-link>
         </mt-tab-item>
      </mt-tabbar>
   </div>
</template>

<style scoped>
.upbox {
  position: relative;
}
.upflag {
  position: absolute;
  left: 43px;
  width: 15px;
  height: 15px;
  text-align: center;
  line-height: 15px;
  border-radius: 10px;
  background-color: red;
  color: #fff;
}
img {
  width: 70px;
  height: 50px;
}

.mint-tabbar > .mint-tab-item.is-selected {
  background-color: #fafafa;
}

.centerContent {
  margin-top: 40px;
}

.forBack {
  position: fixed;
  left: 8px;
  top: 8px;
  z-index: 2;
  color: #fff;
}

.istabshow {
  display: none;
}
</style>
<script>
import bus from "./common/commonvue.js";
export default {
  data() {
    return {
      isbackshow: false,
      isactive: false,
      upflag: 0
    };
  },
  methods: {
    goback: function() {
      this.$router.go(-1);
    },
    isbackshowFun(path) {
      if (path == "/home") {
        this.isbackshow = false;
        this.isactive = false;
      } else {
        this.isbackshow = true;
        this.isactive = true;
      }
    }
  },
  created() {
    this.isbackshowFun(this.$route.path);
    //  bus.$on(
    //    "changeGoods",
    //    function(count) {
    //      this.upflag += count;
    //      console.log(this.upflag);
    //    }.bind(this)
    //  );
  },
  updated() {
    this.upflag = this.$store.getters.getGoodsCount;
  },
  watch: {
    $route: function(newValue, oldValue) {
      this.isbackshowFun(newValue.path);
    }
  }
};
</script>

