<template>
   <div>
     <swipe swipeUrl="api/getlunbo" swipeTime="1000"></swipe>
      <div class="mui-content">
         <ul class="mui-table-view mui-grid-view mui-grid-9">
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <router-link to="/news/newslist">
                  <span class="mui-icon mui-icon-home"></span>
                  <div class="mui-media-body">新闻资讯</div>
               </router-link>
            </li>
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <router-link to="/photo/photolist">
                  <span class="mui-icon mui-icon-email">
                  </span>
                  <div class="mui-media-body">图片分享</div>
               </router-link>
            </li>
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <router-link to="/goods/goodslist">
                  <span class="mui-icon mui-icon-chatbubble"></span>
                  <div class="mui-media-body">商品购买</div>
               </router-link>
            </li>
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <a href="#">
                  <span class="mui-icon mui-icon-location"></span>
                  <div class="mui-media-body">留言反馈</div>
               </a>
            </li>
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <a href="#">
                  <span class="mui-icon mui-icon-search"></span>
                  <div class="mui-media-body">视频专区</div>
               </a>
            </li>
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-sm-3">
               <a href="#">
                  <span class="mui-icon mui-icon-phone"></span>
                  <div class="mui-media-body">联系我们</div>
               </a>
            </li>

         </ul>
      </div>
   </div>
</template>

<style scoped>
.mint-tabbar {
  background-color: #fff;
}

.mui-table-view {
  background-color: #fff;
  border: 0;
}

.mui-table-view-cell.mui-media {
  border: 0;
}

.mui-icon::before {
  content: "";
}

.mui-icon-home {
  background-image: url("../../statics/images/menu3.png");
}

.mui-icon-email {
  background-image: url("../../statics/images/menu4.png");
}

.mui-icon-chatbubble {
  background-image: url("../../statics/images/menu5.png");
}

.mui-icon-location {
  background-image: url("../../statics/images/menu6.png");
}

.mui-icon-search {
  background-image: url("../../statics/images/menu9.png");
}

.mui-icon-phone {
  background-image: url("../../statics/images/menu10.png");
}

.mui-icon {
  width: 50px;
  height: 50px;
  background-size: cover;
}
</style>



<script>
import common from "../../common/common.js";
import swipe from "../subcomponents/subswipe.vue";
export default {
  components: {
    swipe
  }
};
</script>