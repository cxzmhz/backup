<template>
   <div>
       <div class="goodslist">
         <div class="list" v-for="(item,index) in goodsList" :key="item.id">
              <mt-switch @change="statisticCountAndPrice" v-model="item.isOnOff"></mt-switch>
            <div class="img">
              <img :src="item.thumb_path" alt="">
            </div>
            <div class="desc">
              <p>{{item.title}}</p>
              <p>单价：<span>{{item.sell_price}}</span>&nbsp;&nbsp;数量：<span>{{item.count}}</span></p>
            </div>
            <mt-button @click="deleteItem(index)" type="danger" size="small">删除</mt-button>
          </div>
       </div>
       
       <div class="buy">
         <div class="detail">
          <h4>购买详情如下</h4>
          <p>总价: <span>{{totalmoney}}</span>&nbsp;总共：<span>{{totalcount}}</span>件</p>
         </div>
          <mt-button type="danger" size="normal">立即下单</mt-button>
       </div>
   </div>
</template>
   
<style scoped>
.buy {
  display: flex;
  justify-content: space-around;
  align-items: center;
  margin-top: 20px;
  background-color: #aaa;
}
.detail h4 {
  font-size: 20px;
}
.detail p {
  font-size: 16px;
  color: #000;
}
.detail p span {
  color: red;
}
.goodslist {
  padding: 5px;
}
.list {
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 5px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.img {
  width: 75px;
  height: 75px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 3px;
  margin: 0 10px;
}
.img img {
  width: 100%;
  height: 100%;
}
.desc {
  flex: 1;
}
.desc p:first-of-type {
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.desc p:last-of-type span:first-of-type {
  color: red;
  font-size: 16px;
}
</style>
   
<script>
import common from "../../common/common.js";

export default {
  data() {
    return {
      goodsList: [],
      totalcount: 0,
      totalmoney: 0
    };
  },
  created() {
    this.getGoodsData();
  },
  methods: {
    getGoodsData() {
      const obj1 = {};
      const obj2 = this.$store.getters.getGoodsList;
      obj2.forEach(value => {
        if (obj1[value.id]) {
          obj1[value.id] += value.count;
        } else {
          obj1[value.id] = value.count;
        }
      });
      const arr1 = [];
      for (var key in obj1) {
        arr1.push(key);
      }
      let idsString = arr1.join(",");
      let url = `${common.url}api/goods/getshopcarlist/${idsString}`;
      console.log(url);
      this.$http.get(url).then(
        res => {
          this.goodsList = res.body.message;
          this.goodsList.forEach(v => {
            v.count = obj1[v.id];
            v.isOnOff = true;
          });
          console.log(this.goodsList);
          this.statisticCountAndPrice();
        },
        err => {
          console.log(err);
        }
      );
    },
    statisticCountAndPrice() {
      var totalmoney = 0;
      var totalcount = 0;
      this.goodsList.forEach(v => {
        if (v.isOnOff) {
          totalcount += v.count;
          totalmoney += v.sell_price * v.count;
        }
      });
      this.totalcount = totalcount;
      this.totalmoney = totalmoney;
    },
    deleteItem(index) {
      this.$store.commit("deleteGoods", this.goodsList[index].id);
      this.goodsList.splice(index, 1);
      this.statisticCountAndPrice();
      // this.getGoodsData();
    }
  }
};
</script>