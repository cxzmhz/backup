<template>
   <div>
      <ul>
         <li v-for="item in goodslist" :key="item.id">
           <div class="wrap">
             <router-link :to="`/goods/goodsinfo/${item.id}`">
            <div class="imgs">
               <img :src="item.img_url" alt="">
               <p class="title">
                  {{item.title}}
               </p>
            </div>
            <div class="price">
               <div class="money">
                  <span>{{item.sell_price}}</span>
                  <del>{{item.market_price}}</del>
               </div>
               <div class="desc">
                  <span>热卖中</span>
                  <span>剩余{{item.stock_quantity}}件</span>
               </div>
            </div>
            </router-link>
           </div>
         </li>
      </ul>
   </div>
</template>
   
<style scoped>
ul {
  list-style: none;
  margin: 0;
  padding: 0;
  padding-right: 10px;
  width: 100%;
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
}
li {
  width: 50%;
  padding: 10px 0 0 10px;
}
.title {
  height: 42px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.wrap {
  width: 100%;
  height: 100%;
  padding: 3px;
  box-shadow: -2px -2px 2px 1px #ccc;
  border: 1px solid #aaa;
  border-radius: 5px;
}
.imgs img {
  width: 100%;
}
.price {
  background-color: #eee;
  color: #000;
  height: 53px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.money span {
  color: red;
}
.money del {
  margin-left: 5px;
  font-size: 14px;
}
.desc {
  font-size: 12px;
  margin-top: 10px;
  display: flex;
  justify-content: space-between;
}
</style>
   
<script>
import common from "../../common/common.js";

export default {
  data() {
    return {
      goodslist: []
    };
  },
  created() {
    this.getgoodslist();
  },
  methods: {
    getgoodslist() {
      const url = common.url + "api/getgoods";
      this.$http.get(url).then(
        res => {
          this.goodslist = res.body.message;
          // console.log(this.goodslist);
        },
        err => {
          console.log(err);
        }
      );
    }
  }
};
</script>