<template>
   <div class="box">
      <swipe :swipeUrl="`api/getthumimages/${$route.params.goodsId}`" swipeTime="1000"></swipe>
      <div class="title">
         <h4>{{goods.title}}</h4>
         <div class="price">
            市场价:￥<del>{{goods.market_price}}</del>
            销售价:￥<span>{{goods.sell_price}}</span>
         </div>
         <num v-on:changeNum="getNum" :total="goods.stock_quantity"></num>
         <mt-button type="primary" size="small">立即购买</mt-button>
         <mt-button @click="addShopCart" type="danger" size="small">加入购物车</mt-button>
      </div>
      <div class="desc">
         <h5>商品参数</h5>
         <ul>
            <li>商品货号:{{goods.goods_no}}</li>
            <li>库存情况:{{goods.stock_quantity}}</li>
            <li>上架时间:{{goods.add_time|dateFmt}}</li>
         </ul>
      </div>
      <div class="btn">
         <mt-button @click="photoAndText" class="introbtn" plain size="large" type="primary">图文介绍</mt-button>
         <mt-button @click="getComment" plain size="large" type="danger">商品评论</mt-button>
      </div>
   </div>
</template>
   
<style scoped>
.box {
  padding: 8px;
}
.title {
  padding: 5px;
  margin-top: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
.title h4 {
  font-weight: normal;
  color: #0094ff;
  font-size: 16px;
  padding-bottom: 5px;
  border-bottom: 1px solid #ccc;
}
.price {
  font-size: 16px;
  color: #666;
}
.price del {
  font-size: 14px;
}
.price span {
  color: #f00;
}
.desc {
  margin-top: 10px;
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
.desc h5 {
  padding-bottom: 10px;
  border-bottom: 1px solid #ccc;
}
.desc ul {
  margin: 0;
  padding: 0;
  list-style: none;
  font-size: 16px;
}
.btn {
  margin-top: 10px;
  border: 1px solid #ccc;
  padding: 5px;
  border-radius: 5px;
}
.btn .introbtn {
  margin-bottom: 10px;
}
</style>
   
<script>
import common from "../../common/common.js";
import swipe from "../subcomponents/subswipe.vue";
import num from "../subcomponents/subnumber.vue";
// import bus from "../../common/commonvue.js";

export default {
  data() {
    return {
      goods: {},
      swipeinfo: [],
      goodsCount: 1
    };
  },
  created() {
    this.getgoodsinfo();
  },
  methods: {
    getgoodsinfo() {
      const url = `${common.url}api/goods/getinfo/${this.$route.params
        .goodsId}`;
      this.$http.get(url).then(
        res => {
          this.goods = res.body.message[0];
        },
        err => {
          console.log(err);
        }
      );
    },
    photoAndText() {
      this.$router.push({
        name: "photoAndText",
        params: { goodsDescId: this.$route.params.goodsId }
      });
    },
    getComment() {
      this.$router.push({
        path: "/goods/goodscomment",
        query: { commentId: this.$route.params.goodsId }
      });
    },
    getNum(num) {
      // console.log(num);
      this.goodsCount = num;
    },
    addShopCart() {
      // console.log("-----", this.goodsCount);
      // bus.$emit("changeGoods", this.goodsCount);
      this.$store.commit("getMuGoods", {
        id: this.$route.params.goodsId,
        count: this.goodsCount
      });
    }
  },
  components: {
    swipe: swipe,
    num
  }
};
</script>