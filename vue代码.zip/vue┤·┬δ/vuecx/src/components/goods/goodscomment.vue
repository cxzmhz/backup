<template>
   <subcomment :commentId="$route.query.commentId"></subcomment>
</template>
   
<style scoped>

</style>
   
<script>
import common from "../../common/common.js";
import subcomment from "../subcomponents/subcomment.vue";

export default {
  data() {
    return {};
  },
  created() {},
  methods: {},
  components: {
    subcomment: subcomment
  }
};
</script>