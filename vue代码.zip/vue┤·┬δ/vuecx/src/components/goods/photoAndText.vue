<template>
   <div>
      <div class="titleStyle">
         <h3>{{goodsDescObj.title}}</h3>
      </div>
      <div class="contentStyle">
         <p v-html="goodsDescObj.content"></p>
      </div>
   </div>
</template>
<style scoped>
.titleStyle {
  border-bottom: 1px solid rgba(92, 92, 92, 0.3);
}

.titleStyle,
.contentStyle {
  padding: 8px;
  overflow: hidden;
}

.titleStyle h3 {
  font-size: 16px;
  color: #0094ff;
}
img {
  width: 100px !important;
}
</style>

<script>
import common from "../../common/common.js";
export default {
  data() {
    return {
      goodsDescObj: {}
    };
  },
  created() {
    this.getgoodsDesc();
  },
  methods: {
    getgoodsDesc: function() {
      const url = `${common.url}api/goods/getdesc/${this.$route.params
        .goodsDescId}`;
      this.$http.get(url).then(
        res => {
          this.goodsDescObj = res.body.message[0];
          console.log(this.goodsDescObj);
        },
        err => {
          console.log(err);
        }
      );
    }
  }
};
</script>