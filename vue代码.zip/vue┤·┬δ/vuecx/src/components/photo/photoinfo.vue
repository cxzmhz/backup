<template>
   <div>
      <div class="top">
         <h4>{{imginfo.title}}</h4>
         <div>
            <span>{{imginfo.add_time|dateFmt}}</span>&nbsp;
            <span>{{imginfo.click}}次点击</span>
         </div>
      </div>
      <div class="mui-content">
         <ul class="mui-table-view mui-grid-view mui-grid-9">
            <li class="mui-table-view-cell mui-media mui-col-xs-4 mui-col-md-3" v-for="(item,index) in imgs" :key="index">
               <img :src="item.src" alt="" class="preview-img" @click="$preview.open(index, imgs)">
            </li>
         </ul>
      </div>
      <div v-html="imginfo.content" class="desc"></div>
      <subcomment :commentId="$route.params.photoId"></subcomment>
   </div>
</template>
<style scoped>
.top,
.desc {
   padding: 8px;
}

.top h4 {
   color: #0094ff;
}

.top div span {
   font-size: 14px;
}

.desc {
   font-size: 14px;
   color: #666;
}

.mui-content img {
   width: 100%;
}
</style>

<script>
import common from '../../common/common.js'
import subcomment from '../subcomponents/subcomment.vue'
import { Indicator } from 'mint-ui';
export default {
   data() {
      return {
         imginfo: {},
         imgs: []
      }
   },
   created() {
      this.getimginfo();
      this.getimgs();
   },
   methods: {
      getimginfo() {
         Indicator.open('使出吃安慕希的力加载中...');
         const url = common.url + 'api/getimageInfo/' + this.$route.params.photoId;
         this.$http.get(url).then(res => {
            Indicator.close();
            this.imginfo = res.body.message[0];
         }, err => {
            console.log(err);
         })
      },
      getimgs() {
         const url = common.url + 'api/getthumimages/' + this.$route.params.photoId;
         this.$http.get(url).then(res => {
            this.imgs = res.body.message;
            this.imgs.forEach(function(value, index) {
               value.w = 400;
               value.h = 400;
            })
            console.log(this.imgs);
         }, err => {
            console.log(err);
         })
      }
   },
   components: {
      subcomment: subcomment
   }
}
</script>