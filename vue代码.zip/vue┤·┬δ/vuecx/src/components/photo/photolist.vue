<template>
   <div>
      <div class="top">
         <ul class="clearfix">
            <li @click="getcontent(0)">全部</li>
            <li v-for="item in tops" :key="item.id" @click="getcontent(item.id)">{{item.title}}</li>
         </ul>
      </div>
      <div class="content">
         <div class="contentlist" v-for="item in contents" :key="item.id">
            <router-link :to="'/photo/photoinfo/'+item.id">
               <img :src="item.img_url" alt="pic">
               <div class="desc">
                  <h4>{{item.title}}</h4>
                  <p>{{item.zhaiyao}}</p>
               </div>
            </router-link>
         </div>
      </div>
   </div>
</template>
<style scoped>
.top {
  overflow: hidden;
  height: 37px;
}

.top ul {
  overflow: auto;
  list-style: none;
  margin: 0;
  padding: 8px 8px 30px;
  white-space: nowrap;
}

.top ul li {
  display: inline-block;
  color: #0094ff;
  margin-right: 10px;
}

.content {
  padding: 8px;
}

.contentlist {
  position: relative;
  width: 99%;
}

.contentlist img {
  width: 100%;
}

.contentlist .desc {
  position: absolute;
  bottom: 5px;
  color: #fff;
  background-color: rgba(0, 0, 0, 0.4);
}

.contentlist .desc p {
  color: #fff;
}
</style>

<script>
import common from "../../common/common.js";
import { Indicator } from "mint-ui";
export default {
  data() {
    return {
      tops: [],
      contents: []
    };
  },
  created() {
    this.gettop();
    this.getcontent(0);
  },
  beforeDestroy() {
    Indicator.close();
  },
  methods: {
    gettop() {
      const url = common.url + "api/getimgcategory";
      this.$http.get(url).then(
        res => {
          this.tops = res.body.message;
        },
        err => {
          console.log(err);
        }
      );
    },
    getcontent(id) {
      Indicator.open("使出吃键盘的力加载中...");
      const url = common.url + "api/getimages/" + id;
      this.$http.get(url).then(
        res => {
          Indicator.close();
          this.contents = res.body.message;
          console.log(res.body.message);
        },
        err => {
          console.log(err);
        }
      );
    }
  }
};
</script>