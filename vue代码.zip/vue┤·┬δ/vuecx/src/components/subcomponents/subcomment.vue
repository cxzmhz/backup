<template>
   <div>
      <div class="titleStyle">
         <h4>提交评论</h4>
         <textarea name="" id="" ref="txtbox" placeholder="请输入评论的内容" cols="30" rows="5"></textarea>
         <mt-button type="primary" size="large" @click="subcomment()">提交评论</mt-button>
      </div>
      <div class="contentStyle">
         <h4>评论列表</h4>
         <div class="commentStyle" v-for="(item,index) in comments" :key="index">
            <p>{{item.content}}</p>
            <div>
               <span>{{item.user_name}}</span>
               <span>{{item.add_time | dateFmt}}</span>
            </div>
         </div>
         <mt-button class="bottombtn" plain type="danger" size="large" @click="loadmore()">查看更多</mt-button>
      </div>
   </div>
</template>
<style scoped>
.titleStyle,
.contentStyle {
  padding: 8px;
}

.titleStyle h4,
.contentStyle h4 {
  line-height: 30px;
  border-bottom: 1px solid #ccc;
}

.contentStyle .commentStyle {
  min-height: 80px;
  font-size: 14px;
  border-bottom: 1px solid #ccc;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.contentStyle div {
  display: flex;
  justify-content: space-between;
  color: #0094ff;
}

.contentStyle p {
  font-size: 16px;
}

.bottombtn {
  margin-top: 8px;
}
</style>
<script>
import common from "../../common/common.js";
import { Toast } from "mint-ui";
export default {
  data() {
    return {
      comments: [],
      pageindex: 1
    };
  },
  created() {
    this.getcomment();
  },
  methods: {
    getcomment() {
      const url =common.url +"api/getcomments/" +this.commentId + "?pageindex=" +this.pageindex;
      this.$http.get(url).then(
        res => {
          if (this.pageindex == 1) {
            this.comments = res.body.message;
            if (this.comments.length == 0) {
              Toast({
                message: "来快活呀，抢沙发呀",
                position: "middle",
                duration: 3000
              });
            }
          } else {
            if (res.body.message.length == 0) {
              Toast({
                message: "兄台，已经没有更多内容了",
                position: "middle",
                duration: 3000
              });
            }
            this.comments = this.comments.concat(res.body.message);
          }
        },
        err => {
          console.log(err);
        }
      );
    },
    loadmore() {
      this.pageindex++;
      this.getcomment();
    },
    subcomment() {
      var content = this.$refs.txtbox.value;
      if (content.length === 0) {
        Toast({
          message: "请输入评论再提交",
          position: "middle",
          duration: 3000
        });
        return;
      }
      var url = common.url + "api/postcomment/" + this.commentId;
      this.$http.post(url, { content }, { emulateJSON: true }).then(
        res => {
          Toast({
            message: res.body.message,
            position: "middle",
            duration: 3000
          });
          this.pageindex = 1;
          this.getcomment();
          this.$refs.txtbox.value = "";
        },
        err => {
          console.log(err);
        }
      );
    }
  },
  props: ["commentId"]
};
</script>