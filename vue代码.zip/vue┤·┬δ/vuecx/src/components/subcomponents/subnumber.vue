<template>
   <div class="bigbox">
       <div @click="sub" class="gnum sub">-</div>
       <div class="gnum num">{{num}}</div>
       <div @click="add" class="gnum add">+</div>
   </div>
</template>
   
<style scoped>
.bigbox {
  margin: 10px 0;
}
.gnum {
  display: inline-block;
  border: 1px solid #aaa;
  width: 25px;
  height: 25px;
  text-align: center;
  line-height: 25px;
}
.num {
  width: 30px;
}
</style>
   
<script>
import common from "../../common/common.js";

export default {
  data() {
    return {
      num: 1
    };
  },
  created() {},
  methods: {
    add() {
      if (this.num >= this.total) {
        return;
      }
      this.num++;
      this.$emit("changeNum", this.num);
    },
    sub() {
      if (this.num <= 1) {
        return;
      }
      this.num--;
      this.$emit("changeNum", this.num);
    }
  },
  props: ["total"]
};
</script>