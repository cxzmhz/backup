<template>
   <div>
      <mt-swipe :auto="+swipeTime">
         <mt-swipe-item v-for="(item,index) in lunboArr" :key="index">
            <a :href="item.url">
               <img :src="item.src||item.img" alt="lunbotu">
            </a>
         </mt-swipe-item>
      </mt-swipe>
   </div>
</template>
   
<style scoped>
.mint-swipe {
  height: 250px;
}

.mint-swipe img {
  width: 100%;
  height: 250px;
}
</style>
   
<script>
import common from "../../common/common.js";

export default {
  data: function() {
    return {
      lunboArr: []
    };
  },
  created() {
    this.getLunbo();
  },
  methods: {
    getLunbo: function() {
      var url = `${common.url}${this.swipeUrl}`;
      this.$http.get(url).then(
        res => {
          this.lunboArr = res.body.message;
        },
        err => {
          console.log(err);
        }
      );
    }
  },
  props: ["swipeUrl", "swipeTime"]
};
</script>