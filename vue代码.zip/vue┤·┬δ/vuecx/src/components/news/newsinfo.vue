<template>
   <div>
      <div class="titleStyle">
         <h3>{{newsinfoObj.title}}</h3>
         <p>{{newsinfoObj.add_time|dateFmt('YYYY-MM-DD HH:mm')}}&nbsp;&nbsp;{{newsinfoObj.click}}次点击</p>
      </div>
      <div class="contentStyle">
         <p v-html="newsinfoObj.content"></p>
      </div>
      <subcomment :commentId="$route.params.newsId"></subcomment>
   </div>
</template>
<style scoped>
.titleStyle {
  border-bottom: 1px solid rgba(92, 92, 92, 0.3);
}

.titleStyle,
.contentStyle {
  padding: 8px;
}

.titleStyle h3 {
  font-size: 16px;
  color: #0094ff;
}
</style>

<script>
import common from "../../common/common.js";
import subcomment from "../subcomponents/subcomment.vue";
export default {
  data() {
    return {
      newsinfoObj: {}
    };
  },
  created() {
    this.getNewsinfo();
  },
  methods: {
    getNewsinfo: function() {
      var url = common.url + "api/getnew/" + this.$route.params.newsId;
      this.$http.get(url).then(
        res => {
          this.newsinfoObj = res.body.message[0];
        },
        err => {
          console.log(err);
        }
      );
    }
  },
  components: {
    subcomment: subcomment
  }
};
</script>