<template>
   <div class="mui-content">
      <ul class="mui-table-view">
         <li class="mui-table-view-cell mui-media" v-for="item in newslistArr" :key="item.id">
            <router-link :to="'/news/newsinfo/'+item.id">
               <img class="mui-media-object mui-pull-left" :src="item.img_url">
               <div class="mui-media-body">
                  <p class='titleStyle'>{{item.title}}</p>
                  <p class='mui-ellipsis'>
                     <span>{{item.add_time | dateFmt('YYYY-MM-DD HH:mm:ss')}}</span>
                     <span>点击数{{item.click}}次</span>
                  </p>
               </div>
            </router-link>
         </li>
      </ul>
   </div>
</template>
<style scoped>
.mui-table-view-cell {
   height: 80px;
}

.mui-table-view-cell .mui-media-object {
   min-width: 65px;
   height: 65px;
}

.titleStyle {
   font-size: 14px;
   color: gray;
   overflow: hidden;
   text-overflow: ellipsis;
   white-space: nowrap;
}

.mui-table-view-cell .mui-ellipsis {
   margin-top: 20px;
   font-size: 12px;
   color: #0094ff;
   display: flex;
   justify-content: space-between;
}
</style>

<script>
import common from '../../common/common.js'
export default {
   data() {
      return {
         newslistArr: []
      }
   },
   created() {
      this.getNewslist();
   },
   methods: {
      getNewslist: function() {
         const url = common.url + "api/getnewslist";
         this.$http.get(url).then(res => {
            this.newslistArr = res.body.message;
         }, err => {
            console.log(err);
         })
      }
   }
}
</script>