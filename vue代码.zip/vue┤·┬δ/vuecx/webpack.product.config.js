
var path = require('path')
var HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
   entry: './src/main.js',
   output: {
      path: path.join(__dirname, 'dist'),
      filename: 'bundle.js'
   },
   module: {
      rules: [
         {
            test: /\.vue$/,
            use: [
               { loader: 'vue-loader' }
            ]
         },
         {
            test: /\.css$/,
            use: [
               { loader: 'style-loader' },
               { loader: 'css-loader' }
            ]
         },
         {
            test: /\.(ttf|png|jpg|gif|svg)$/,
            use: [
               { loader: 'url-loader' }
            ]
         }
      ]
   },
   plugins: [
      new HtmlWebpackPlugin({  // Also generate a test.html 
         template: './template.html',
         filename: 'index.html'
      })
   ]
}